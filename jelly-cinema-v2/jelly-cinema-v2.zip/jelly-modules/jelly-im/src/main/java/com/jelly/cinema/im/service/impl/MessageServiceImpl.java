package com.jelly.cinema.im.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jelly.cinema.common.core.domain.PageQuery;
import com.jelly.cinema.common.core.domain.PageResult;
import com.jelly.cinema.common.core.exception.ServiceException;
import com.jelly.cinema.common.redis.service.RedisService;
import com.jelly.cinema.im.domain.dto.MessageDTO;
import com.jelly.cinema.im.domain.entity.ChatMessage;
import com.jelly.cinema.im.domain.vo.MessageVO;
import com.jelly.cinema.im.domain.vo.SessionVO;
import com.jelly.cinema.im.mapper.ChatMessageMapper;
import com.jelly.cinema.im.mq.MessageProducer;
import com.jelly.cinema.im.service.MessageService;
import com.jelly.cinema.im.websocket.ChatWebSocketHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 消息服务实现
 *
 * @author Jelly Cinema
 */
@Slf4j
@Service
public class MessageServiceImpl implements MessageService {

    private final ChatMessageMapper chatMessageMapper;
    private final RedisService redisService;
    private final ChatWebSocketHandler webSocketHandler;
    
    @Autowired(required = false)
    private MessageProducer messageProducer;
    
    public MessageServiceImpl(ChatMessageMapper chatMessageMapper, 
                              RedisService redisService, 
                              ChatWebSocketHandler webSocketHandler) {
        this.chatMessageMapper = chatMessageMapper;
        this.redisService = redisService;
        this.webSocketHandler = webSocketHandler;
    }

    private static final String SESSION_KEY = "jelly:im:session:";
    private static final String MSG_SEQ_KEY = "jelly:im:seq:";

    @Override
    public void sendMessage(Long fromId, MessageDTO dto) {
        // 生成会话 ID
        String sessionId = generateSessionId(fromId, dto.getToId(), dto.getCmdType());

        // 生成消息序列号
        Long msgSeq = redisService.increment(MSG_SEQ_KEY + sessionId);

        // 构建消息
        ChatMessage message = new ChatMessage();
        message.setSessionId(sessionId);
        message.setFromId(fromId);
        message.setToId(dto.getToId());
        message.setCmdType(dto.getCmdType());
        message.setMsgType(dto.getMsgType());
        message.setContent(dto.getContent());
        message.setExtra(dto.getExtra());
        message.setMsgSeq(msgSeq);
        message.setStatus(0);

        // 写入 Redis Timeline（用于快速拉取）
        String timelineKey = SESSION_KEY + sessionId + ":timeline";
        MessageVO vo = toVO(message);
        redisService.zAdd(timelineKey, JSONUtil.toJsonStr(vo), System.currentTimeMillis());

        // 发送到 MQ 异步持久化（如果 MQ 可用）
        if (messageProducer != null) {
            messageProducer.sendMessage(message);
        } else {
            // MQ 不可用，直接同步写入数据库
            chatMessageMapper.insert(message);
        }

        // 实时推送给接收方
        if (webSocketHandler.isOnline(dto.getToId())) {
            String pushJson = JSONUtil.toJsonStr(Map.of(
                    "type", "message",
                    "data", vo
            ));
            webSocketHandler.sendToUser(dto.getToId(), pushJson);
        }

        log.info("消息发送成功: {} -> {}, sessionId={}", fromId, dto.getToId(), sessionId);
    }

    @Override
    public List<SessionVO> getSessionList(Long userId) {
        // 查询用户的所有会话
        LambdaQueryWrapper<ChatMessage> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ChatMessage::getFromId, userId)
                .or()
                .eq(ChatMessage::getToId, userId);
        wrapper.eq(ChatMessage::getCmdType, 1); // 私聊
        wrapper.orderByDesc(ChatMessage::getCreateTime);

        List<ChatMessage> messages = chatMessageMapper.selectList(wrapper);

        // 按会话分组，取最后一条
        Map<String, ChatMessage> sessionMap = messages.stream()
                .collect(Collectors.toMap(
                        ChatMessage::getSessionId,
                        m -> m,
                        (m1, m2) -> m1.getCreateTime().isAfter(m2.getCreateTime()) ? m1 : m2
                ));

        // 构建会话列表
        List<SessionVO> result = new ArrayList<>();
        for (ChatMessage msg : sessionMap.values()) {
            SessionVO vo = new SessionVO();
            vo.setSessionId(msg.getSessionId());
            vo.setType(msg.getCmdType());
            vo.setUserId(msg.getFromId().equals(userId) ? msg.getToId() : msg.getFromId());
            vo.setLastMessage(msg.getContent());
            vo.setLastTime(msg.getCreateTime());
            vo.setUnreadCount(0); // TODO: 计算未读数
            // TODO: 查询用户信息填充 nickname 和 avatar
            result.add(vo);
        }

        return result;
    }

    @Override
    public PageResult<MessageVO> getHistory(String sessionId, PageQuery query) {
        LambdaQueryWrapper<ChatMessage> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ChatMessage::getSessionId, sessionId);
        wrapper.eq(ChatMessage::getStatus, 0);
        wrapper.orderByDesc(ChatMessage::getMsgSeq);

        Page<ChatMessage> page = chatMessageMapper.selectPage(
                new Page<>(query.getPageNum(), query.getPageSize()),
                wrapper
        );

        List<MessageVO> voList = page.getRecords().stream()
                .map(this::toVO)
                .collect(Collectors.toList());

        return PageResult.build(voList, page.getTotal(), query.getPageNum(), query.getPageSize());
    }

    @Override
    public void recallMessage(Long userId, Long messageId) {
        ChatMessage message = chatMessageMapper.selectById(messageId);
        if (message == null) {
            throw new ServiceException("消息不存在");
        }

        if (!message.getFromId().equals(userId)) {
            throw new ServiceException("无权撤回此消息");
        }

        // 检查是否超过 2 分钟
        if (Duration.between(message.getCreateTime(), LocalDateTime.now()).toMinutes() > 2) {
            throw new ServiceException("超过 2 分钟的消息无法撤回");
        }

        message.setStatus(1);
        chatMessageMapper.updateById(message);

        // 通知接收方撤回
        if (webSocketHandler.isOnline(message.getToId())) {
            String pushJson = JSONUtil.toJsonStr(Map.of(
                    "type", "recall",
                    "messageId", messageId
            ));
            webSocketHandler.sendToUser(message.getToId(), pushJson);
        }
    }

    /**
     * 生成会话 ID
     */
    private String generateSessionId(Long userId1, Long userId2, Integer cmdType) {
        if (cmdType == 2) {
            // 群聊直接用群 ID
            return "group_" + userId2;
        }
        // 私聊：min_max 格式
        long min = Math.min(userId1, userId2);
        long max = Math.max(userId1, userId2);
        return min + "_" + max;
    }

    /**
     * 转换为 VO
     */
    private MessageVO toVO(ChatMessage message) {
        MessageVO vo = BeanUtil.copyProperties(message, MessageVO.class);
        // TODO: 查询用户信息
        return vo;
    }
}
