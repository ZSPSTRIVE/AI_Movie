package com.jelly.cinema.im.domain.vo;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 消息 VO
 *
 * @author Jelly Cinema
 */
@Data
public class MessageVO implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    private String sessionId;

    private Long fromId;

    private String fromNickname;

    private String fromAvatar;

    private Long toId;

    private Integer cmdType;

    private Integer msgType;

    private String content;

    private String extra;

    private Long msgSeq;

    private LocalDateTime createTime;

    /**
     * 消息状态：0-正常，1-撤回
     */
    private Integer status;
}
