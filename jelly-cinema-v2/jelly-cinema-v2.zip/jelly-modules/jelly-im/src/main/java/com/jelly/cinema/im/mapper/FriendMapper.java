package com.jelly.cinema.im.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jelly.cinema.im.domain.entity.Friend;
import org.apache.ibatis.annotations.Mapper;

/**
 * 好友关系 Mapper
 *
 * @author Jelly Cinema
 */
@Mapper
public interface FriendMapper extends BaseMapper<Friend> {

}
