package com.jelly.cinema.im.controller;

import com.jelly.cinema.common.core.domain.PageQuery;
import com.jelly.cinema.common.core.domain.PageResult;
import com.jelly.cinema.common.core.domain.R;
import com.jelly.cinema.common.security.utils.LoginHelper;
import com.jelly.cinema.im.domain.vo.MessageVO;
import com.jelly.cinema.im.domain.vo.SessionVO;
import com.jelly.cinema.im.service.MessageService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 消息控制器
 *
 * @author Jelly Cinema
 */
@Tag(name = "IM 消息管理")
@RestController
@RequestMapping("/im")
@RequiredArgsConstructor
public class MessageController {

    private final MessageService messageService;

    @Operation(summary = "获取会话列表")
    @GetMapping("/sessions")
    public R<List<SessionVO>> getSessions() {
        Long userId = LoginHelper.getUserId();
        return R.ok(messageService.getSessionList(userId));
    }

    @Operation(summary = "获取历史消息")
    @GetMapping("/history/{sessionId}")
    public R<PageResult<MessageVO>> getHistory(
            @PathVariable String sessionId,
            PageQuery query) {
        return R.ok(messageService.getHistory(sessionId, query));
    }

    @Operation(summary = "撤回消息")
    @PostMapping("/recall/{messageId}")
    public R<Void> recall(@PathVariable Long messageId) {
        Long userId = LoginHelper.getUserId();
        messageService.recallMessage(userId, messageId);
        return R.ok();
    }
}
