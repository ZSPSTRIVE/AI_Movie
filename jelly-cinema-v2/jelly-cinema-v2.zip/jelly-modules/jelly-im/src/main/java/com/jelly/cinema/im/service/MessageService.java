package com.jelly.cinema.im.service;

import com.jelly.cinema.common.core.domain.PageQuery;
import com.jelly.cinema.common.core.domain.PageResult;
import com.jelly.cinema.im.domain.dto.MessageDTO;
import com.jelly.cinema.im.domain.vo.MessageVO;
import com.jelly.cinema.im.domain.vo.SessionVO;

import java.util.List;

/**
 * 消息服务接口
 *
 * @author Jelly Cinema
 */
public interface MessageService {

    /**
     * 发送消息
     *
     * @param fromId 发送者 ID
     * @param dto    消息内容
     */
    void sendMessage(Long fromId, MessageDTO dto);

    /**
     * 获取会话列表
     *
     * @param userId 用户 ID
     * @return 会话列表
     */
    List<SessionVO> getSessionList(Long userId);

    /**
     * 获取历史消息
     *
     * @param sessionId 会话 ID
     * @param query     分页参数
     * @return 消息列表
     */
    PageResult<MessageVO> getHistory(String sessionId, PageQuery query);

    /**
     * 撤回消息
     *
     * @param userId    用户 ID
     * @param messageId 消息 ID
     */
    void recallMessage(Long userId, Long messageId);
}
