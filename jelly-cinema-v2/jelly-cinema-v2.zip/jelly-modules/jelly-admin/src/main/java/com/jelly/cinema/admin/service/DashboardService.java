package com.jelly.cinema.admin.service;

import com.jelly.cinema.admin.domain.vo.DashboardVO;

/**
 * 仪表盘服务接口
 *
 * @author Jelly Cinema
 */
public interface DashboardService {

    /**
     * 获取统计数据
     */
    DashboardVO getStatistics();
}
