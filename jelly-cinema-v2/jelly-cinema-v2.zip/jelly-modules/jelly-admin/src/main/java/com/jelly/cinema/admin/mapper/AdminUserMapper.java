package com.jelly.cinema.admin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jelly.cinema.admin.domain.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

/**
 * 用户 Mapper（管理端）
 *
 * @author Jelly Cinema
 */
@Mapper
public interface AdminUserMapper extends BaseMapper<User> {

    /**
     * 统计用户总数
     */
    @Select("SELECT COUNT(*) FROM t_user WHERE deleted = 0")
    Long countTotal();

    /**
     * 统计今日新增用户
     */
    @Select("SELECT COUNT(*) FROM t_user WHERE deleted = 0 AND DATE(create_time) = CURDATE()")
    Long countTodayNew();
}
