package com.jelly.cinema.admin.service.impl;

import com.jelly.cinema.admin.domain.vo.DashboardVO;
import com.jelly.cinema.admin.mapper.AdminFilmMapper;
import com.jelly.cinema.admin.mapper.AdminPostMapper;
import com.jelly.cinema.admin.mapper.AdminUserMapper;
import com.jelly.cinema.admin.service.DashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * 仪表盘服务实现
 *
 * @author Jelly Cinema
 */
@Service
@RequiredArgsConstructor
public class DashboardServiceImpl implements DashboardService {

    private final AdminUserMapper userMapper;
    private final AdminFilmMapper filmMapper;
    private final AdminPostMapper postMapper;

    @Override
    public DashboardVO getStatistics() {
        DashboardVO vo = new DashboardVO();
        vo.setUserCount(userMapper.countTotal());
        vo.setFilmCount(filmMapper.countTotal());
        vo.setPostCount(postMapper.countTotal());
        vo.setTodayNewUsers(userMapper.countTodayNew());
        vo.setTodayPlayCount(filmMapper.sumPlayCount());
        vo.setWeeklyActiveUsers(0L); // TODO: 实现周活跃用户统计
        return vo;
    }
}
